<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.layouts.master','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="container px-6 mx-auto grid">
        <h2 class="my-2 text-2xl font-semibold text-gray-700 dark:text-gray-200">
            Domain list </h2>

        
        <div class="px-4 ">
            <ol class="flex justify-end text-gray-500">
                <li class="flex mr-3">
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="hover:text-gray-900">Dashboard</a>
                </li>
                <li class="mr-3">/ </li>
                <li>
                    <a href="<?php echo e(route('domains.index')); ?>" class="text-gray-900 dark:text-white">
                        Domain</a>
                </li>
            </ol>
        </div>


        <div class="px-2 py-2">

            
            <div class="px-2 py-2 ">
                <a href="<?php echo e(route('domains.create')); ?>"
                    class="inline-block px-4 py-2 shadow-md text-sm font-medium leading-5 text-white transition-colors duration-150 bg-blue-600 border border-transparent rounded-lg active:bg-blue-800 hover:bg-blue-700 focus:outline-none focus:shadow-outline-blue">
                    Create Domain
                </a>
            </div>
            <div class="p-4 mb-8 bg-white rounded-lg shadow-md dark:bg-gray-800">
                <div class="px-2">
                    
                    <?php if(session('message')): ?>
                        <div
                            class="bg-green-100 border-t-4 border-green-500 rounded-b text-green-900 px-4 py-3 shadow-md my-4">
                            <div class="flex items-center">
                                <div class="w-6 h-6 mr-4 bg-green-500 rounded-full flex-shrink-0"></div>
                                <div class="flex-1">
                                    <?php echo e(session('message')); ?>

                                </div>
                                <button type="button"
                                    class="text-gray-500 hover:text-gray-600 focus:outline-none focus:text-gray-600"
                                    data-dismiss="alert" aria-label="Close"
                                    onclick="this.parentElement.parentElement.style.display='none'">
                                    <svg class="w-4 h-4 fill-current" viewBox="0 0 20 20"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M6.293 6.293a1 1 0 011.414 0L10 8.586l2.293-2.293a1 1 0 111.414 1.414L11.414 10l2.293 2.293a1 1 0 01-1.414 1.414L10 11.414l-2.293 2.293a1 1 0 01-1.414-1.414L8.586 10 6.293 7.707a1 1 0 010-1.414z">
                                        </path>
                                    </svg>
                                </button>
                            </div>
                        </div>
                    <?php endif; ?>


                    
                    <div class="p-8 mb-8 bg-white rounded-lg shadow-md dark:bg-gray-800">
                        <table class="w-full">
                            <thead>
                                <tr class="text-left text-gray-500 bg-gray-100 dark:bg-gray-700">
                                    <th class="px-4 py-3">Sl.</th>
                                    <th class="px-4 py-3">Name</th>
                                    <th class="px-4 py-3">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                                <?php
                                    $starting_serial = ($domains->currentPage() - 1) * $domains->perPage() + 1;
                                ?>
                                <?php $__currentLoopData = $domains; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $domain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="border-t border-gray-200 dark:border-gray-700">
                                        <td class="px-4 py-3"><?php echo e($starting_serial++); ?></td>
                                        <td class="px-4 py-3"><?php echo e($domain->name); ?></td>
                                        <td class="px-4 py-3">
                                            <a href="<?php echo e(route('domains.show', $domain->id)); ?>"
                                                class="inline-block px-3 py-1 text-sm font-semibold leading-tight text-white transition duration-200 bg-blue-600 rounded-md hover:bg-blue-800">
                                                Show
                                            </a>
                                            <a href="<?php echo e(route('domains.edit', $domain->id)); ?>"
                                                class="inline-block px-3 py-1 text-sm font-semibold leading-tight text-yellow-600 transition duration-200 bg-yellow-200 rounded-md hover:bg-yellow-300 ml-2">
                                                Edit
                                            </a>
                                            <form action="<?php echo e(route('domains.destroy', $domain->id)); ?>" method="POST"
                                                class="inline-block">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit"
                                                    class="inline-block px-3 py-1 text-sm font-semibold leading-tight text-red-600 transition duration-200 bg-red-200 rounded-md hover:bg-red-300 ml-2"
                                                    onclick="return confirm('Are you sure you want to delete this domain?')">
                                                    Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="flex items-center justify-start mt-4">
                        <nav class="flex items-center">
                            
                            <?php if($domains->onFirstPage()): ?>
                                <span
                                    class="px-2 py-1 text-sm font-medium leading-5 text-gray-400 cursor-not-allowed">First</span>
                                <span
                                    class="px-2 py-1 text-sm font-medium leading-5 text-gray-400 cursor-not-allowed">Previous</span>
                            <?php else: ?>
                                <a href="<?php echo e($domains->url(1)); ?>"
                                    class="relative inline-flex items-center px-2 py-1 text-sm font-medium leading-5 text-blue-600 transition duration-150 ease-in-out border rounded-md cursor-pointer hover:text-blue-800">First</a>
                                <a href="<?php echo e($domains->previousPageUrl()); ?>"
                                    class="relative inline-flex items-center px-2 py-1 text-sm font-medium leading-5 text-blue-600 transition duration-150 ease-in-out border rounded-md cursor-pointer hover:text-blue-800">Previous</a>
                            <?php endif; ?>

                            
                            <span class="px-2 py-1 text-sm font-medium leading-5 text-gray-600">
                                Page: <?php echo e($domains->currentPage()); ?> of <?php echo e($domains->lastPage()); ?> Records:
                                <?php echo e($domains->total()); ?>

                            </span>

                            
                            <?php if($domains->hasMorePages()): ?>
                                <a href="<?php echo e($domains->nextPageUrl()); ?>"
                                    class="relative inline-flex items-center px-2 py-1 text-sm font-medium leading-5 text-blue-600 transition duration-150 ease-in-out border rounded-md cursor-pointer hover:text-blue-800">Next</a>
                                <a href="<?php echo e($domains->url($domains->lastPage())); ?>"
                                    class="relative inline-flex items-center px-2 py-1 text-sm font-medium leading-5 text-blue-600 transition duration-150 ease-in-out border rounded-md cursor-pointer hover:text-blue-800">Last</a>
                            <?php else: ?>
                                <span
                                    class="px-2 py-1 text-sm font-medium leading-5 text-gray-400 cursor-not-allowed">Next</span>
                                <span
                                    class="px-2 py-1 text-sm font-medium leading-5 text-gray-400 cursor-not-allowed">Last</span>
                            <?php endif; ?>
                        </nav>
                    </div>

                </div>

            </div>
        </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\pams\resources\views/backend/admin/domain/index.blade.php ENDPATH**/ ?>