<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.student.layouts.master','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend.student.layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container px-6 mx-auto grid">
        <h2 class="my-6 text-2xl font-semibold text-gray-700 dark:text-gray-200">
            Student Profile
        </h2>

        
        <div class="px-4 mb-4">
            <ol class="flex justify-end text-gray-500">
                <li class="flex mr-3">
                    <a href="<?php echo e(route('student.dashboard')); ?>" class="hover:text-gray-900">Dashboard</a>
                </li>
                <li class="mr-3">/</li>
                <li>
                    <a href="<?php echo e(route('student.profile')); ?>" class="text-gray-900 dark:text-white">Student Profile</a>
                </li>
            </ol>
        </div>

        

        <div class="px-2 py-2 mb-2">
            <div class="container mx-auto mt-8 p-4 bg-white shadow-md rounded-lg">
                <?php if(session('message')): ?>
                    <div class="relative top-1/4  w-full bg-green-200 text-green-700 px-4 py-4 rounded-lg shadow"
                        id="alert">
                        <?php echo e(session('message')); ?>

                        <button type="button"
                            class="absolute ml-2 right-6 text-green-700 hover:text-green-900 focus:outline-none"
                            onclick="dismissAlert()">
                            <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"
                                    d="M6 18L18 6M6 6l12 12">
                                </path>
                            </svg>
                        </button>
                    </div><br>
                <?php endif; ?>
                <div class="flex justify-end">
                    <button class="bg-purple-500 hover:bg-purple-600 text-white font-bold mt-8 py-2 px-4 rounded">
                        <a href="<?php echo e(route('student.profileEdit')); ?>">Edit</a>
                    </button>
                </div>
                <div class="grid grid-cols-3 gap-4 mb-4">
                    <span class="text-gray-700 font-bold mb-2 col-span-1">Student ID:</span>
                    <span class="col-span-2"><?php echo e($user->student->student_id); ?></span>
                </div>
                <div class="grid grid-cols-3 gap-4 mb-4">
                    <span class="text-gray-700 font-bold mb-2 col-span-1">First Name:</span>
                    <span class="col-span-2"><?php echo e($user->first_name); ?></span>
                </div>
                <div class="grid grid-cols-3 gap-4 mb-4">
                    <span class="text-gray-700 font-bold mb-2 col-span-1">Last Name:</span>
                    <span class="col-span-2"><?php echo e($user->last_name); ?></span>
                </div>
                <div class="grid grid-cols-3 gap-4 mb-4">
                    <span class="text-gray-700 font-bold mb-2 col-span-1">Email:</span>
                    <span class="col-span-2"><?php echo e($user->email); ?></span>
                </div>
                <div class="grid grid-cols-3 gap-4 mb-4">
                    <span class="text-gray-700 font-bold mb-2 col-span-1">Phone Number:</span>
                    <span class="col-span-2"><?php echo e($user->phone_number); ?></span>
                </div>
                <div class="grid grid-cols-3 gap-4 mb-4">
                    <span class="text-gray-700 font-bold mb-2 col-span-1">Department:</span>
                    <span class="col-span-2"><?php echo e($user->department); ?></span>
                </div>
                <div class="grid grid-cols-3 gap-4 mb-4">
                    <span class="text-gray-700 font-bold mb-2 col-span-1">Batch:</span>
                    <span class="col-span-2"><?php echo e($user->student->batch); ?></span>
                </div>
                <div class="grid grid-cols-3 gap-4 mb-4">
                    <span class="text-gray-700 font-bold mb-2 col-span-1">Section:</span>
                    <span class="col-span-2"><?php echo e($user->student->section); ?></span>
                </div>
                <div class="grid grid-cols-3 gap-4 mb-4">
                    <span class="text-gray-700 font-bold mb-2 col-span-1">Shift:</span>
                    <span class="col-span-2"><?php echo e($user->student->shift); ?></span>
                </div>

                <div class="grid grid-cols-3 gap-4 mb-4">
                    <span class="text-gray-700 font-bold mb-2 col-span-1">Project Type:</span>
                    <?php if($user->student->project_type_status === 0): ?>
                        <span class="col-span-2 text-red-600">Set your project type</span>
                    <?php else: ?>
                        <?php
                            $projectType = json_decode($user->student->project_type, true);
                            
                            foreach ($projectType as $key => $value) {
                                $projectType[$key] = ucfirst($value);
                            }
                        ?>
                        <span class="col-span-2">
                            <?php $__currentLoopData = $projectType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($type); ?>

                                <?php if(!$loop->last): ?>
                                    ,
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </span>
                    <?php endif; ?>
                </div>


                <div class="grid grid-cols-3 gap-4 mb-4">
                    <span class="text-gray-700 font-bold mb-2 col-span-1">Domain:</span>
                    <?php if($user->student->domain === 'null' || $user->student->domain === null): ?>
                        <span class="col-span-2 text-green-600">Not set yet</span>
                    <?php else: ?>
                        <?php
                            $domain = json_decode($user->student->domain, true);
                        ?>
                        <span class="col-span-2">
                            <?php $__currentLoopData = $domain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($item); ?>

                                <?php if(!$loop->last): ?>
                                    ,
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </span>
                    <?php endif; ?>
                </div>






            </div>
        </div>

    </div>

    <script>
        function dismissAlert() {
            var alert = document.getElementById('alert');
            alert.style.display = 'none';
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\pams\resources\views/frontend/student/profile.blade.php ENDPATH**/ ?>