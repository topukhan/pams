<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.student.layouts.master','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend.student.layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="container px-6 mx-auto grid">
        <h2 class="my-6 text-2xl font-semibold text-gray-700 dark:text-gray-200">
            Genre and Supervisor Availabilty</h2>

        
        <div class="px-4 mb-4">
            <ol class="flex justify-end text-gray-500">
                <li class="flex mr-3">
                    <a href="#" class="hover:text-gray-900">Dashboard</a>
                </li>
                <li class="mr-3">/ </li>
                <li>
                    <a href="<?php echo e(route('student.supervisor.availability')); ?>" class="text-gray-900 dark:text-white">Supervisor Availabilty</a>
                </li>
            </ol>
        </div>

        
        <div class="px-2 py-2">
            <div class="w-full mb-8 overflow-hidden border rounded-lg shadow-lg">
                <div class="w-full overflow-x-auto shadow-lg">
                    <table class="w-full whitespace-no-wrap ">
                        <thead>
                            <tr
                                class="text-xs font-semibold tracking-wide text-left text-gray-500 uppercase border-b dark:border-gray-700 bg-gray-50 dark:text-gray-400 dark:bg-gray-800">
                                <th class="px-3 py-3">Sl</th>
                                <th class="px-3 py-3">Faculty Names</th>
                                <th class="px-3 py-3">Email</th>
                                <th class="px-3 py-3">Phone</th>
                                <th class="px-3 py-3">Interest/Genre</th>
                                <th class="px-3 py-3">Availability</th>
                                <th class="px-3 py-3">Proposal</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y dark:divide-gray-700 dark:bg-gray-800">

                            

                            <?php $__currentLoopData = $supervisors->sortByDesc('availability'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supervisor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-gray-700 dark:text-gray-400">
                                    <td class="px-4 py-3 text-sm"><?php echo e($loop->iteration); ?></td>
                                    <td class="px-4 py-3 font-semibold text-sm ">
                                        <?php echo e($supervisor->user->first_name . ' ' . $supervisor->user->last_name); ?></td>
                                    <td class="px-4 py-3 font-semibold text-sm "><?php echo e($supervisor->user->email); ?></td>
                                    <td class="px-4 py-3 font-semibold  text-sm "><?php echo e($supervisor->user->phone_number); ?>

                                    </td>
                                    <td class="px-4 py-3 font-semibold  text-sm "><?php echo e($supervisor->expertise_area); ?></td>
                                    <td class="px-4 py-3 font-semibold  text-sm ">
                                        <?php
                                            $yes = 'Yes';
                                            $no = 'No';
                                            if ($supervisor->availability == 1) {
                                                echo $yes;
                                            } else {
                                                echo $no;
                                            }
                                            
                                        ?>
                                    </td>
                                    <td class="px-4 py-3 text-xs">
                                        <?php if($supervisor->availability == 1): ?>
                                            <a href="<?php echo e(route('student.proposalForm', ['id' => $supervisor->id])); ?>">
                                                <button
                                                    class="px-2 py-1 font-semibold leading-tight text-green-800 bg-green-200 rounded-full dark:bg-green-700 dark:text-green-200">
                                                    Request
                                                </button>
                                            </a>
                                        <?php endif; ?>
                                        <?php if($supervisor->availability == 0): ?>
                                            <a href="<?php echo e(route('student.proposalForm', ['id' => $supervisor->id])); ?>">
                                                <button disabled
                                                    class="px-4 py-1 font-semibold leading-tight text-green-800 bg-red-200 rounded-full dark:bg-red-700 dark:text-green-200">
                                                    N/A
                                                </button>
                                            </a>
                                        <?php endif; ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>
                </div>
            </div>

        </div>

        </table>
    </div>
    </div>

    </div>
    </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\pams\resources\views/frontend/student/supervisorAvailability.blade.php ENDPATH**/ ?>